#!/usr/bin/env python3
"""
parse-auth-log.py

Parses a Linux auth.log (or similar) for failed/successful SSH login attempts
and summarizes brute-force-style activity by source IP. Useful for validating
detection logic (see detection-rules/sigma-bruteforce-ssh.yml) against real
log output from the Metasploitable2 target after running a Hydra attempt.

Usage:
    python3 parse-auth-log.py /path/to/auth.log
"""

import re
import sys
from collections import defaultdict

FAILED_RE = re.compile(r"Failed password for (\S+) from (\d+\.\d+\.\d+\.\d+)")
SUCCESS_RE = re.compile(r"Accepted password for (\S+) from (\d+\.\d+\.\d+\.\d+)")


def parse_log(path: str):
    failed_by_ip = defaultdict(int)
    success_by_ip = defaultdict(list)

    with open(path, "r", errors="ignore") as f:
        for line in f:
            fail_match = FAILED_RE.search(line)
            if fail_match:
                user, ip = fail_match.groups()
                failed_by_ip[ip] += 1
                continue

            success_match = SUCCESS_RE.search(line)
            if success_match:
                user, ip = success_match.groups()
                success_by_ip[ip].append(user)

    return failed_by_ip, success_by_ip


def main():
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <path-to-auth.log>")
        sys.exit(1)

    log_path = sys.argv[1]
    failed_by_ip, success_by_ip = parse_log(log_path)

    print("=== Failed Login Attempts by Source IP ===")
    for ip, count in sorted(failed_by_ip.items(), key=lambda x: -x[1]):
        flag = "  <-- possible brute force" if count >= 5 else ""
        print(f"{ip:>15}  {count:>4} failed attempts{flag}")

    print("\n=== Successful Logins by Source IP ===")
    for ip, users in success_by_ip.items():
        print(f"{ip:>15}  succeeded as: {', '.join(users)}")

    print("\n=== Correlation: IPs with failures AND a later success ===")
    for ip in success_by_ip:
        if failed_by_ip.get(ip, 0) >= 5:
            print(f"{ip:>15}  {failed_by_ip[ip]} failures then success -> LIKELY BRUTE FORCE")


if __name__ == "__main__":
    main()
