#!/usr/bin/env bash
#
# recon-nmap.sh
# Reusable reconnaissance scan against the lab's target zone.
# Run from the Kali attacker VM.
#
# Usage: ./recon-nmap.sh [target-range] [output-dir]
# Example: ./recon-nmap.sh 10.10.10.30-32 ./scan-results

set -euo pipefail

TARGET_RANGE="${1:-10.10.10.30-32}"
OUTPUT_DIR="${2:-./scan-results}"
TIMESTAMP="$(date +%Y%m%d-%H%M%S)"

mkdir -p "${OUTPUT_DIR}"

echo "[*] Starting recon scan against ${TARGET_RANGE}"
echo "[*] Output will be saved to ${OUTPUT_DIR}/"

# Host discovery
nmap -sn "${TARGET_RANGE}" -oN "${OUTPUT_DIR}/${TIMESTAMP}-hosts-up.txt"

# Full TCP port + service/version detection + default scripts
nmap -sV -sC -p- -T4 "${TARGET_RANGE}" \
    -oN "${OUTPUT_DIR}/${TIMESTAMP}-full-scan.txt" \
    -oX "${OUTPUT_DIR}/${TIMESTAMP}-full-scan.xml"

# Common UDP ports (a light pass — full UDP scans are slow)
nmap -sU --top-ports 20 "${TARGET_RANGE}" \
    -oN "${OUTPUT_DIR}/${TIMESTAMP}-udp-scan.txt"

echo "[*] Recon complete. Review ${OUTPUT_DIR}/${TIMESTAMP}-full-scan.txt for next steps."
