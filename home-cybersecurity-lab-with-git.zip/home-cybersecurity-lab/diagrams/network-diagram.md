# Network Diagram & IP Plan

## Topology

```mermaid
flowchart TB
    WAN["Physical Host NIC<br/>(NAT to real internet — used ONLY for updates,<br/>never bridged to lab-internal traffic)"]

    subgraph HOST["Hypervisor Host (VirtualBox/Proxmox)"]
        subgraph LABNET["Lab-Internal Network: 10.10.10.0/24 (Host-Only)"]
            FW["pfSense<br/>WAN: NAT (updates only)<br/>LAN: 10.10.10.1/24"]
            KALI["Kali Linux (Attacker)<br/>10.10.10.20"]
            META["Metasploitable2 (Target)<br/>10.10.10.30"]
            DVWA["DVWA (Target)<br/>10.10.10.31"]
            WIN["Windows Eval VM (Target)<br/>10.10.10.32"]
            SIEM["Security Onion / ELK (Blue Team)<br/>10.10.10.40"]

            FW --> KALI
            FW --> META
            FW --> DVWA
            FW --> WIN
            FW --> SIEM
        end
    end

    HOST -.optional NAT for patching only.-> WAN
```

## IP Address Plan

| Host | Role | IP | OS |
|---|---|---|---|
| pfSense | Firewall / router / segmentation | 10.10.10.1 | FreeBSD (pfSense) |
| Kali Linux | Attacker | 10.10.10.20 | Debian-based (Kali) |
| Metasploitable2 | Target — general Linux services | 10.10.10.30 | Ubuntu 8.04 (intentionally old/vulnerable) |
| DVWA | Target — web application | 10.10.10.31 | Linux + Apache/MySQL/PHP |
| Windows Eval VM | Target — enterprise-realistic | 10.10.10.32 | Windows 10/11 (90-day eval) |
| Security Onion / ELK | Detection / SIEM | 10.10.10.40 | Ubuntu-based |

## Network Design Notes

- **Host-only / internal network mode** in VirtualBox (or an internal Linux bridge in Proxmox) means these VMs can talk to each other but have **no route to your real home LAN** unless you explicitly configure NAT for patching.
- pfSense acts as the router/firewall for the lab subnet and is where zone-to-zone firewall rules live (e.g., "target zone cannot initiate connections to blue zone," "only Kali can reach targets on attack ports").
- If you want true VLAN-style segmentation instead of one flat /24, create three internal networks in the hypervisor (red/target/blue) and let pfSense route between them with explicit allow rules — this is more advanced and worth mentioning on a resume as "network segmentation" experience.
- SIEM host either sits as a passive listener (via a virtual SPAN/mirror port on the hypervisor's virtual switch, if supported) or ingests logs actively forwarded from each target (Winlogbeat on Windows, Filebeat/rsyslog on Linux, plus pfSense log export).
