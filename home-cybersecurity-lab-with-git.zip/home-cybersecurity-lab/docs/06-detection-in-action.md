# Phase 6 — Detection In Action

## Goal
Re-run the Phase 4 attacks and watch them get caught by the SIEM — then write custom detection rules tuned to your specific attacks.

## 6.1 Re-run and Observe

1. Revert Kali and the target to the clean snapshots taken earlier.
2. Re-run the vsftpd backdoor exploit from Phase 4.
3. In Kibana / Security Onion's alert dashboard, look for the corresponding Suricata alert (default signature sets often already flag this).
4. Repeat for the DVWA SQL injection and XSS attempts — note whether default signatures catch them (often they need tuning — this is the interesting part).

## 6.2 Write a Custom Suricata Rule

Default rulesets won't catch everything, especially SQL injection against your specific app. Write your own — see `detection-rules/suricata-custom.rules` for a working example that flags the `' OR '1'='1` pattern used in Phase 4.

Load it into Suricata:
```bash
sudo cp detection-rules/suricata-custom.rules /etc/suricata/rules/
sudo suricata-update
sudo systemctl restart suricata
```

## 6.3 Write a Sigma Rule

Sigma rules are SIEM-agnostic detection logic (convertible to Elastic, Splunk, etc.) — useful to show you understand detection engineering beyond one specific tool. See `detection-rules/sigma-bruteforce-ssh.yml` for an example detecting repeated failed SSH logins (useful if you also practice `hydra` brute-force attempts against Metasploitable2's SSH service).

## 6.4 Confirm Detection Works

Re-run the attack a third time. Confirm:
- The custom Suricata rule fires and shows up as an alert in the dashboard.
- The alert includes enough context (source IP, destination, payload snippet) that an analyst could act on it.

Screenshot the alert — this is strong portfolio evidence: "I didn't just run an exploit, I proved it gets detected."

## Why This Matters for a Resume
Writing and validating custom detection content (not just installing a SIEM) is what separates "I clicked through an ELK tutorial" from actual detection-engineering skill. This is a direct, provable skill for SOC analyst, detection engineer, and threat-hunting roles.

## Verification Checklist
- [ ] Default signatures caught at least one Phase 4 attack
- [ ] A custom Suricata rule was written and loaded successfully
- [ ] The custom rule fires correctly when the attack is re-run
- [ ] A Sigma rule was written for at least one additional detection scenario
