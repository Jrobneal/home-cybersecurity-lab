# Phase 8 — Lessons Learned / Retrospective

_Use this doc as a template — fill it in with your own experience once you've actually built and run the lab. This is the section hiring managers often read most closely, because it shows how you think, not just what you clicked._

## What Went Well

- _(example) Segmenting the network with pfSense was more involved than expected but made the SIEM's job much easier — traffic patterns were cleaner and easier to correlate._

## What Was Harder Than Expected

- _(example) Getting Security Onion's promiscuous-mode sniffing to work inside VirtualBox required switching to "Internal Network" mode with promiscuous policy set to "Allow All" on every adapter — not obvious from the docs._

## What I'd Do Differently Next Time

- _(example) Would automate the VM builds with Vagrant from the start instead of manually clicking through installers — rebuilding the lab from scratch took longer than it should have._

## Skills I Practiced That I Didn't Expect To

- _(example) Spent more time on log parsing/regex (see `scripts/parse-auth-log.py`) than on the actual exploitation — a good reminder that detection engineering is mostly data wrangling._

## Next Extensions I Want to Try

- Small Active Directory domain + BloodHound attack path mapping
- Infrastructure-as-code rebuild (Vagrant + Ansible)
- A honeypot (Cowrie) exposed carefully to see real internet scanning traffic
