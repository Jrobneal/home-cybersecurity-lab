# Phase 3 — Vulnerable Target Machines

## Goal
Deploy deliberately vulnerable machines to attack safely and legally (you own them, they were built for this purpose).

## Targets

### 1. Metasploitable2
- Download from the official Rapid7/SourceForge Metasploitable2 image.
- Import as a VM, attach to the lab network only (10.10.10.30).
- **Never expose this VM to a real network or the internet** — it is intentionally full of unpatched, exploitable services.
- Default credentials are published (msfadmin/msfadmin) — useful for practicing post-exploitation once you're in.

### 2. DVWA (Damn Vulnerable Web Application)
- Easiest path: use the official DVWA Docker image.
  ```bash
  docker run --rm -it -p 80:80 vulnerables/web-dvwa
  ```
- Or install manually on a small Linux VM (Apache + MySQL + PHP) if you want the extra Linux admin practice.
- Set security level to "low" for your first pass, then raise it as you get comfortable — DVWA is designed to teach the *same* vulnerability at increasing difficulty.
- Attach to the lab network at 10.10.10.31.

### 3. Windows 10/11 Evaluation VM (optional but recommended)
- Microsoft provides free 90-day evaluation VMs for Windows 10/11 for exactly this kind of testing.
- Gives you a realistic enterprise target — useful for practicing things like SMB enumeration, weak local account attacks, and (later, as an extension) Active Directory attack paths.
- Attach to the lab network at 10.10.10.32.

## Why This Matters for a Resume
Shows you know the standard, industry-recognized "safe to attack" platforms (this matters — it tells an interviewer you understand legal/ethical boundaries) and that you can stand up both Linux and Windows targets.

## Verification Checklist
- [ ] Metasploitable2 boots and responds to ping from Kali
- [ ] DVWA login page loads in a browser from Kali
- [ ] (Optional) Windows eval VM boots and is reachable on the lab network
- [ ] None of the targets are reachable from your real home network
