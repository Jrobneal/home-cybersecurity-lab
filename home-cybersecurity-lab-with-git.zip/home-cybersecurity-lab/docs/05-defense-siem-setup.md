# Phase 5 — Defense: SIEM / Detection Setup

## Goal
Stand up a detection platform that can see and alert on the attacks run in Phase 4.

## Option A: Security Onion (recommended, all-in-one)

1. Download the Security Onion 2 ISO.
2. Install as a VM with at least 4 CPU cores and 8GB RAM (this is the heaviest VM in the lab).
3. During setup, choose **"Standalone"** install mode (single VM handling everything: Suricata, Zeek, Elasticsearch, Kibana).
4. Assign the monitor interface to the lab-internal network, IP `10.10.10.40`.
5. If your hypervisor's virtual switch supports port mirroring/promiscuous mode, configure Security Onion's sniffing interface in promiscuous mode so it can passively see traffic between other lab VMs (this is closest to how a real network tap/SPAN port setup works).
   - If promiscuous mirroring isn't available in your hypervisor, forward logs actively instead (see step 6).
6. Configure log forwarding from targets:
   - **Linux targets:** install Filebeat, point it at the Security Onion Elasticsearch/Logstash endpoint.
   - **Windows target:** install Winlogbeat, forward Security and Sysmon event logs.
   - **pfSense:** enable remote syslog forwarding to `10.10.10.40`.

## Option B: Manual ELK Stack (more setup work, more resume credit for "built it myself")

1. Deploy a Linux VM (Ubuntu Server) at `10.10.10.40`.
2. Install Elasticsearch, Logstash, and Kibana individually.
3. Install Suricata separately in IDS mode on the same VM or on a dedicated sensor VM, configure it to write EVE JSON logs.
4. Point Logstash/Filebeat at Suricata's log output and at forwarded target logs, same as Option A step 6.

## Verify Data Is Flowing

- Open Kibana (`http://10.10.10.40:5601` for Security Onion's dashboards, or your own Kibana index).
- Confirm you see log events from at least one target and from Suricata.
- Generate a small bit of traffic (e.g., `ping` between VMs) and confirm it shows up within a minute or two.

## Why This Matters for a Resume
Deploying and validating a SIEM pipeline — not just installing software but proving logs actually flow end-to-end — is exactly the kind of task a SOC analyst or detection engineer does in their first weeks on the job.

## Verification Checklist
- [ ] Security Onion / ELK is reachable via its web dashboard
- [ ] At least one target's logs are visible in the SIEM
- [ ] Suricata is running and producing alerts on test traffic
