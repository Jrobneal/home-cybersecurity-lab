# Phase 2 — Attacker VM (Kali Linux)

## Goal
Stand up the offensive platform you'll use for all recon and exploitation in this lab.

## Steps

1. Download the official Kali Linux VM image or ISO from [kali.org](https://www.kali.org/get-kali/).
2. Create the VM with at least 2 CPU cores, 4GB RAM, 40GB disk.
3. Attach its network adapter to the lab-internal network only (10.10.10.20 per the IP plan).
4. On first boot:
   ```bash
   sudo apt update && sudo apt full-upgrade -y
   ```
5. Confirm the core toolset is present (Kali ships with most of this pre-installed):
   - `nmap` — network/service discovery
   - `metasploit-framework` — exploitation framework
   - `burpsuite` — web application testing proxy
   - `sqlmap` — automated SQL injection testing
   - `hydra` — credential brute-forcing (used carefully, see Phase 4)
   - `wireshark` — packet capture/analysis

6. Take a **snapshot** of the clean VM state before your first attack — this lets you reset to a known-good baseline and re-run attacks repeatably for your write-ups (and for the detection-testing loop in Phase 6).

## Why This Matters for a Resume
Shows familiarity with the standard offensive-security toolchain that shows up in real pentest job descriptions (OSCP-adjacent tooling), and shows you understand VM snapshotting/repeatability — a habit that separates "clicked buttons once" from "built a repeatable test environment."

## Verification Checklist
- [ ] Kali VM boots and is fully updated
- [ ] Kali can ping every target VM on the lab network
- [ ] Kali cannot reach your real home network
- [ ] A clean snapshot exists before any attack is run
