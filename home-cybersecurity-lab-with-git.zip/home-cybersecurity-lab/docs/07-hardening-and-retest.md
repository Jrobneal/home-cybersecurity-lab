# Phase 7 — Hardening & Retest

## Goal
Close the loop: fix a vulnerability you exploited, then prove the fix actually works by re-attacking.

## 7.1 Pick a Finding to Remediate

Good candidates from this lab:
- vsftpd 2.3.4 backdoor on Metasploitable2 → the "fix" in a real environment would be patching to a non-backdoored version; in this lab, you can instead demonstrate the concept by disabling the vulnerable service and re-scanning to confirm it's gone.
- DVWA SQL injection → raise DVWA's security level from "low" to "medium" or "high," which introduces basic input sanitization, and demonstrate the same payload now fails.
- Weak/default credentials (msfadmin/msfadmin) → change them and show that a Hydra brute-force attempt against the new credentials fails within a reasonable attempt budget.

## 7.2 Apply the Fix

Document the *before* state (vulnerable config/version) and the *after* state (patched/hardened config) with screenshots or config diffs.

## 7.3 Re-attack

Run the exact same attack from Phase 4 against the hardened target:
- Confirm the exploit **no longer succeeds**, or
- Confirm it's now **detected and blocked** (if you added a pfSense firewall rule or Suricata `drop` rule in IPS mode instead of a pure config fix).

## 7.4 Document the Loop

This "attack → detect → fix → verify" cycle is the single most compelling narrative for interviews. Capture it as a short before/after table, e.g.:

| Vulnerability | Before | Attack Result (Before) | Fix Applied | Attack Result (After) |
|---|---|---|---|---|
| DVWA SQL injection | Security level: low | Auth bypass succeeded | Raised to security level: medium (input escaping) | Payload rejected, login fails as expected |

## Why This Matters for a Resume
Most portfolio projects stop at "I exploited a vulnerable box." Going one step further — remediating and verifying the fix — demonstrates you understand the *purpose* of security work: reducing risk, not just finding it.
