# Phase 1 — Hypervisor & Network Foundation

## Goal
Build an isolated virtual network so every attack and every target in this lab is fully contained, with zero risk to a real home network or the internet.

## Steps

1. **Install a hypervisor.**
   - VirtualBox (free, simplest) — good if this is your first lab.
   - Proxmox VE (free, bare-metal) — better resume line if you want "hypervisor administration" experience, since it's what many real infrastructure/security teams actually run.

2. **Create an isolated internal network.**
   - VirtualBox: set each lab VM's network adapter to **Host-only Adapter** (or **Internal Network** for even stricter isolation — no host access at all).
   - Proxmox: create an internal-only Linux bridge (e.g., `vmbr1`) that is not attached to any physical NIC.
   - Confirm isolation by trying to ping your real router's IP from inside a lab VM — it should fail.

3. **Deploy pfSense as the lab router/firewall.**
   - Download the pfSense CE ISO, create a VM with two virtual NICs:
     - WAN — bridged to your host's real network *only if* you want patching access (optional, and should be firewalled down afterward).
     - LAN — attached to the isolated lab network (10.10.10.0/24 in this plan).
   - Walk through the pfSense setup wizard, assign `10.10.10.1/24` to the LAN interface.
   - Enable DHCP on the LAN interface (or use static IPs per the plan in `diagrams/network-diagram.md`).

4. **Document the network.**
   - Screenshot the VirtualBox/Proxmox network settings and the pfSense dashboard.
   - Save the IP plan (already in `diagrams/network-diagram.md`) — this is what you'll show in an interview.

## Why This Matters for a Resume
This phase alone demonstrates: hypervisor administration, network segmentation, firewall configuration, and — critically — safe lab hygiene. Interviewers care a lot about whether a candidate understands isolation and blast radius before they ever run an exploit.

## Verification Checklist
- [ ] Lab VMs cannot reach your real home network
- [ ] Lab VMs can reach each other on the 10.10.10.0/24 subnet
- [ ] pfSense dashboard shows LAN interface up with correct IP
- [ ] (Optional) WAN patching access works, but is disabled/firewalled when not actively used
