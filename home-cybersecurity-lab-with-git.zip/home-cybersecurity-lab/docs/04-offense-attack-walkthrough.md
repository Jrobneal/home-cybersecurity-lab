# Phase 4 — Offense: Attack Walkthrough

## Goal
Run a realistic, documented attack chain against the lab targets: reconnaissance → exploitation → post-exploitation. Every step here should be screenshotted for your portfolio/write-up.

## 4.1 Reconnaissance

From Kali, scan the target zone:

```bash
nmap -sV -sC -p- 10.10.10.30 -oN metasploitable2-scan.txt
```

See `scripts/recon-nmap.sh` for a reusable recon script that scans the whole target range and saves output per host.

What to look for: open ports, service versions, anything clearly outdated (Metasploitable2 will show several).

## 4.2 Exploitation (Metasploit example)

Example against a known Metasploitable2 service (vsftpd 2.3.4 backdoor is a classic teaching example):

```bash
msfconsole
use exploit/unix/ftp/vsftpd_234_backdoor
set RHOSTS 10.10.10.30
run
```

Document: which module, which CVE/advisory it corresponds to, and what access you got (shell, user context).

## 4.3 Manual Web Exploitation (DVWA)

Do at least one exploit **without** a framework, so you understand the mechanics:

**SQL Injection (DVWA, low security):**
```
' OR '1'='1
```
in the login or ID field — demonstrates classic SQLi bypassing authentication or dumping data.

**Reflected XSS (DVWA, low security):**
```html
<script>alert('xss')</script>
```
in a search/input field that reflects back unsanitized.

Then repeat with `sqlmap` for the automated version and compare what it finds vs. your manual pass:
```bash
sqlmap -u "http://10.10.10.31/vulnerabilities/sqli/?id=1&Submit=Submit" --cookie="PHPSESSID=..." --dump
```

## 4.4 Post-Exploitation

Once you have a shell on a target:
- Enumerate the user context (`whoami`, `id`)
- Look for locally stored credentials, config files, or writable SUID binaries
- Document what an attacker could pivot to next (this is the "impact" section of a real pentest report)

## Documentation Habit

For every exploit you run, capture:
1. The command/payload used
2. A screenshot of the result
3. What CVE or vulnerability class it maps to
4. What real-world impact it would have

This becomes the "Findings" section of `reports/pentest-report-template.md`.

## Why This Matters for a Resume
This is the core offensive-security narrative: recon → exploit → manual verification → post-exploitation → documented impact. It mirrors exactly how a junior pentester's engagement is structured and evaluated.
