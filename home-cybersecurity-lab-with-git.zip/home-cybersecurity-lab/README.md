# Home Cybersecurity Lab

A self-hosted, fully virtualized security lab demonstrating both **offensive** (penetration testing) and **defensive** (SOC/detection engineering) skills — built end-to-end, documented, and reproducible.

Author: J. Neal ([jrobneal@gmail.com](mailto:jrobneal@gmail.com))

---

## Why This Exists

Most "I did some CTFs" resume lines don't show how someone thinks about a full security lifecycle. This project simulates one: stand up vulnerable infrastructure, attack it, detect the attack, fix the weakness, and prove the fix works — then document all of it like a real engagement.

## Architecture

```mermaid
flowchart TB
    subgraph Internet["Home Network (isolated — no internet bridging)"]
        direction TB
    end

    subgraph LAB["Virtual Lab Network — 10.10.10.0/24 (Host-Only / Internal)"]
        FW["pfSense Firewall/Router<br/>10.10.10.1<br/>(segments zones, logs traffic)"]

        subgraph RedZone["Red Team Zone"]
            KALI["Kali Linux<br/>10.10.10.20<br/>Nmap · Metasploit · Burp Suite"]
        end

        subgraph TargetZone["Target Zone"]
            META["Metasploitable2<br/>10.10.10.30"]
            DVWA["DVWA (Web App)<br/>10.10.10.31"]
            WIN["Windows 10/11 Eval VM<br/>10.10.10.32"]
        end

        subgraph BlueZone["Blue Team Zone"]
            SIEM["Security Onion / ELK<br/>10.10.10.40<br/>Suricata · Zeek · Kibana"]
        end

        FW --- RedZone
        FW --- TargetZone
        FW --- BlueZone
        KALI -.attacks.-> META
        KALI -.attacks.-> DVWA
        KALI -.attacks.-> WIN
        TargetZone -.logs/traffic.-> SIEM
        FW -.netflow/logs.-> SIEM
    end
```

All traffic stays inside a **host-only virtual network** — nothing here ever touches a real production network or the internet-facing router.

## Components

| Layer | Tool | Purpose |
|---|---|---|
| Hypervisor | VirtualBox (or Proxmox) | Hosts all VMs |
| Network segmentation | pfSense | Firewall rules, VLAN-style zone separation, traffic logging |
| Attacker | Kali Linux | Recon, exploitation, web app attacks |
| Targets | Metasploitable2, DVWA, Windows Eval VM | Deliberately vulnerable hosts |
| Detection | Security Onion (Suricata + Zeek) or ELK Stack | Log aggregation, IDS alerting, dashboards |
| Detection rules | Suricata / Sigma | Custom signatures written for the specific attacks run in this lab |

## Repository Structure

```
home-cybersecurity-lab/
├── README.md                      ← you are here
├── diagrams/
│   └── network-diagram.md         ← standalone network diagram + IP plan
├── docs/
│   ├── 01-hypervisor-and-network.md
│   ├── 02-attacker-vm-kali.md
│   ├── 03-vulnerable-targets.md
│   ├── 04-offense-attack-walkthrough.md
│   ├── 05-defense-siem-setup.md
│   ├── 06-detection-in-action.md
│   ├── 07-hardening-and-retest.md
│   └── 08-lessons-learned.md
├── detection-rules/
│   ├── suricata-custom.rules
│   └── sigma-bruteforce-ssh.yml
├── scripts/
│   ├── recon-nmap.sh
│   └── parse-auth-log.py
├── reports/
│   └── pentest-report-template.md
└── LICENSE
```

## Build Phases (Summary)

1. **[Hypervisor & Network](docs/01-hypervisor-and-network.md)** — isolated host-only network, pfSense segmentation.
2. **[Attacker VM](docs/02-attacker-vm-kali.md)** — Kali Linux setup and toolchain.
3. **[Vulnerable Targets](docs/03-vulnerable-targets.md)** — Metasploitable2, DVWA, Windows eval VM.
4. **[Offense Walkthrough](docs/04-offense-attack-walkthrough.md)** — recon → exploitation → post-exploitation.
5. **[Defense / SIEM Setup](docs/05-defense-siem-setup.md)** — Security Onion / ELK deployment and log forwarding.
6. **[Detection in Action](docs/06-detection-in-action.md)** — re-running attacks and watching them get caught, custom rules.
7. **[Hardening & Retest](docs/07-hardening-and-retest.md)** — patch, re-attack, verify the fix holds.
8. **[Lessons Learned](docs/08-lessons-learned.md)** — retrospective, what I'd improve, next extensions.

Sample pentest report: **[reports/pentest-report-template.md](reports/pentest-report-template.md)**

## Skills Demonstrated

- **Offensive security:** reconnaissance (Nmap), exploitation (Metasploit), manual web app attacks (SQL injection, XSS on DVWA)
- **Defensive security / SOC:** SIEM deployment, log ingestion, IDS/NSM (Suricata, Zeek), custom detection rule writing (Suricata + Sigma)
- **Networking & systems administration:** virtual network segmentation, firewall configuration (pfSense), Linux and Windows administration
- **Documentation:** professional pentest-report writing, remediation verification, technical writing

## Extensions (Roadmap)

- [ ] Add a small Active Directory domain and practice AD attack paths (Kerberoasting, BloodHound)
- [ ] Automate the build with Vagrant + Ansible (Infrastructure as Code)
- [ ] Forward logs to a cloud SIEM trial (Splunk / Wazuh) for cloud-adjacent experience
- [ ] Add a honeypot (e.g., Cowrie) to capture real internet-facing attack attempts safely

## Safety Notice

Every host in this lab runs on an **isolated, host-only virtual network** with no route to the internet or to any production network. All tools and techniques are used only against systems I own and built specifically to be attacked. Do not point any of these tools at systems you don't own or don't have explicit written authorization to test.

## License

MIT — see [LICENSE](LICENSE).
